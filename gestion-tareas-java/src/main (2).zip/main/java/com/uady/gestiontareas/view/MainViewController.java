package com.uady.gestiontareas.view;

import com.uady.gestiontareas.controller.TaskController;
import com.uady.gestiontareas.model.Task;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class MainViewController {

    @FXML
    private TableView<Task> taskTable;
    @FXML
    private TableColumn<Task, String> titleColumn;
    @FXML
    private TableColumn<Task, String> descriptionColumn;
    @FXML
    private TableColumn<Task, String> dueDateColumn;
    @FXML
    private TableColumn<Task, String> priorityColumn;
    @FXML
    private TableColumn<Task, String> statusColumn;

    private TaskController taskController;
    private ObservableList<Task> taskList;

    @FXML
    public void initialize() {
        taskController = new TaskController();
        taskController.loadTasks();
        taskList = FXCollections.observableArrayList(taskController.getAllTasks());

        // Configurar columnas
        titleColumn.setCellValueFactory(
                data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getTitle()));
        descriptionColumn.setCellValueFactory(
                data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getDescription()));
        dueDateColumn.setCellValueFactory(
                data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getDueDate().toString()));
        priorityColumn.setCellValueFactory(
                data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getPriority().toString()));
        statusColumn.setCellValueFactory(
                data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getStatus().toString()));

        taskTable.setItems(taskList);
    }

    @FXML
    private void handleAdd() {
        System.out.println("Agregar tarea - funcionalidad pendiente");
    }

    @FXML
    private void handleEdit() {
        System.out.println("Editar tarea - funcionalidad pendiente");
    }

    @FXML
    private void handleDelete() {
        Task selected = taskTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            taskController.deleteTask(selected.getId());
            taskList.setAll(taskController.getAllTasks());
        }
    }
}
