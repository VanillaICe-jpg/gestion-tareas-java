package com.uady.gestiontareas.model;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.lang.reflect.Type;
import java.util.List;

public class TaskFileManager {

    private static final String FILE_PATH = "task.json";

    // Cargar tareas desde el archivo JSON
    public static List<Task> loadTasks() {
        try {
            if (!Files.exists(Paths.get(FILE_PATH))) {
                return List.of(); // Si el archivo no existe, retornamos una lista vacía
            }

            Gson gson = new Gson();
            FileReader reader = new FileReader(FILE_PATH);
            Type listType = new TypeToken<List<Task>>() {
            }.getType();
            return gson.fromJson(reader, listType);
        } catch (IOException e) {
            e.printStackTrace(); // Mejorar manejo de errores (ej. logs)
            return List.of(); // Si hay error, devolvemos lista vacía
        }
    }

    // Guardar tareas en el archivo JSON
    public static void saveTasks(List<Task> tasks) {
        try {
            Gson gson = new Gson();
            FileWriter writer = new FileWriter(FILE_PATH);
            gson.toJson(tasks, writer);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace(); // Mejorar manejo de errores (ej. logs)
        }
    }
}
