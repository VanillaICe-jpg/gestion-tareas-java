package com.uady.gestiontareas.model;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.*;
import com.uady.gestiontareas.model.TaskFileManager;

public class TaskFileManager {

    private static final String FILE_PATH = "tasks.txt";

    public class TaskController {
        private List<Task> tasks;

        public TaskController() {
            this.tasks = TaskFileManager.loadTasks();
        }

        public List<Task> getTasks() {
            return tasks;
        }

        public void saveTasks() {
            TaskFileManager.saveTasks(tasks);
        }
    }

    public static void saveTasks(List<Task> tasks) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Task task : tasks) {
                writer.write(task.getId() + ";" +
                        task.getTitle() + ";" +
                        task.getDescription() + ";" +
                        task.getDueDate() + ";" +
                        task.getPriority() + ";" +
                        task.getStatus());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("❌ Error saving tasks: " + e.getMessage());
        }
    }

    public static List<Task> loadTasks() {
        List<Task> tasks = new ArrayList<>();
        File file = new File(FILE_PATH);
        if (!file.exists())
            return tasks;

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(";");
                if (fields.length == 6) {
                    Task task = new Task(fields[1], fields[2],
                            LocalDate.parse(fields[3]),
                            Priority.valueOf(fields[4]),
                            Status.valueOf(fields[5]));
                    task.setId(fields[0]);
                    tasks.add(task);
                }
            }
        } catch (IOException e) {
            System.out.println("❌ Error loading tasks: " + e.getMessage());
        }

        return tasks;
    }
}
