package com.uady.gestiontareas.controller;

import com.uady.gestiontareas.model.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.*;
import com.uady.gestiontareas.model.TaskFileManager;

public class TaskController {
    private final List<Task> tasks;

    public TaskController() {
        this.tasks = TaskFileManager.loadTasks();
    }

    public boolean addTask(String title, String description, LocalDate dueDate, Priority priority, Status status) {
        if (title == null || title.trim().isEmpty())
            return false;
        if (dueDate.isBefore(LocalDate.now()))
            return false;

        Task task = new Task(title, description, dueDate, priority, status);
        tasks.add(task);
        return true;
    }

    public List<Task> getAllTasks() {
        return tasks;
    }

    public List<Task> getTasksSortedByDate() {
        return tasks.stream()
                .sorted(Comparator.comparing(Task::getDueDate))
                .toList();
    }

    public List<Task> getTasksSortedByPriority() {
        return tasks.stream()
                .sorted(Comparator.comparing(Task::getPriority))
                .toList();
    }

    public Task getTaskById(String id) {
        return tasks.stream()
                .filter(t -> t.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public boolean updateTask(String id, String title, String description, LocalDate dueDate, Priority priority,
            Status status) {
        Task task = getTaskById(id);
        if (task == null)
            return false;

        task.setTitle(title);
        task.setDescription(description);
        task.setDueDate(dueDate);
        task.setPriority(priority);
        task.setStatus(status);
        return true;
    }

    public boolean deleteTask(String id) {
        return tasks.removeIf(t -> t.getId().equals(id));
    }

    public List<Task> searchTasksByTitle(String query) {
        return tasks.stream()
                .filter(t -> t.getTitle().toLowerCase().contains(query.toLowerCase()))
                .toList();
    }

    public void saveTasks() {
        TaskFileManager.saveTasks(tasks);
    }

    public void loadTasks() {
        List<Task> loadedTasks = TaskFileManager.loadTasks();
        if (loadedTasks != null) {
            tasks.clear();
            tasks.addAll(loadedTasks);
        }
    }

    public List<Task> filterByStatus(Status status) {
        return tasks.stream()
                .filter(task -> task.getStatus() == status)
                .toList();
    }

    public List<Task> filterByPriority(Priority priority) {
        return tasks.stream()
                .filter(task -> task.getPriority() == priority)
                .toList();
    }

    public List<Task> filterByDateRange(LocalDate start, LocalDate end) {
        return tasks.stream()
                .filter(task -> !task.getDueDate().isBefore(start) && !task.getDueDate().isAfter(end))
                .toList();
    }

}
